// applicationDataGrid.test.js

import React from 'react';
import { render, screen, fireEvent, waitFor} from '@testing-library/react';
import axios from 'axios';
import ApplicationDataGrid from '../Components/Applications/ApplicationDataGrid';

import { BrowserRouter } from 'react-router-dom';
import { RowContext } from '../App';
import { mockRowContextValues } from './common.test';
import { getGridFields } from '../DynamicGrid/headerConfig';
import { useCookies } from 'react-cookie';
import  { basicUrl } from '../Services/apiheader';
import MockAdapter from 'axios-mock-adapter';
import { GET_API } from "../Services/apiheader";
import service from '../Services/apiheader';
import { fetchCookies, fetchReasons } from '../apis/apiFunctions';

jest.mock('react-cookie', () => ({
  useCookies: jest.fn(),
}));

jest.mock('../DynamicGrid/headerConfig', () => ({
  GetGridHeaders: jest.fn(),
  getGridFields: jest.fn(),
}));

jest.mock('../apis/apiFunctions', () => ({
  fetchReasons: jest.fn(),
  fetchCookies:jest.fn()
}));


const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,
}));

const mockAxios=new MockAdapter(axios);
const mock = new MockAdapter(service);
describe('ApplicationDataGrid Component', () => {
  beforeEach(() => {
   

    mock.onPut('/application/v1/status-disable/1').reply(200, { data:{application_id:1} });
    (fetchCookies as jest.Mock).mockResolvedValue([{ name: "edit_application" }, { name: "view_application" }, { name: "delete_application" },{name:"add_application"}]);
    const gridfields = [
      {
        id: "1",
        column: "testcolumn",
        type: "type",
        gridAvailability: 'true',
        visibility: 'true',
        fieldName: 'fileld',
        order: '1',
      }
    ];
    (getGridFields as jest.Mock).mockResolvedValue(gridfields);
    const mockDatanew = ["setreason1","setreason2"]

    const mockReasons = [
      { id: '1', name: 'Reason 1',value:"value1" },
      { id: '2', name: 'Reason 2', value:"value2"},
    ];
    (fetchReasons as jest.Mock).mockResolvedValue(mockReasons);

    mockAxios.onGet(`${GET_API}syslib/form-manager/menus/module?module=applications`).reply(200, mockDatanew);

  });
  beforeEach(() => {
    mockAxios.reset();
    const rows = [{ id: 1, productName: 'Product 1', application_identifier: 'app-1' }];
    const mockData = {
      status: 200,
      data: { application_id: 'APPID001' }
    };
    mock.onPut(`${basicUrl}application/v1/status-disable/${rows[0].id}`).reply(200, mockData);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('renders component with initial loading state', async () => {
    const { container}=render(<BrowserRouter>
      <RowContext.Provider value={mockRowContextValues}>
        <ApplicationDataGrid />
      </RowContext.Provider>
    </BrowserRouter>);
    
    const loadingIndicator = container.querySelector('.loading-spinner');
    expect(loadingIndicator).toBeInTheDocument();
   
  });

  test('reads cookies and sets user privileges', async () => {
    render(
     
        <RowContext.Provider value={mockRowContextValues}>
          <BrowserRouter>
            <ApplicationDataGrid />
          </BrowserRouter>
        </RowContext.Provider>
     
    );

    await waitFor(() => {
      expect(mockRowContextValues.setIsAddPrivileged).toHaveBeenCalledWith(true);
    });
  });

  test('fetches and sets grid columns', async () => {
    render(
      
        <RowContext.Provider value={mockRowContextValues}>
          <BrowserRouter>
            <ApplicationDataGrid />
          </BrowserRouter>
        </RowContext.Provider>
      
    );

    await waitFor(() => {
      expect(getGridFields).toHaveBeenCalled();
    });
  });

  test('handles edit action', async () => {
    const rows = [{ id: 1, productName: 'Product 1', application_identifier: 'app-1' }];
    mockRowContextValues.rows = rows;

    render(
      
        <RowContext.Provider value={mockRowContextValues}>
          <BrowserRouter>
            <ApplicationDataGrid />
          </BrowserRouter>
        </RowContext.Provider>
    
    );

    expect(screen.getByRole('menu')).toBeInTheDocument();

    const moreButton = await screen.findByRole('menuitem', { name: /more/i });
    fireEvent.click(moreButton);
    const editIcon = await screen.findByTestId('edit-icon');
    fireEvent.click(editIcon);

    await waitFor(() => {
      expect(mockNavigate).toHaveBeenCalledWith('/editApplication');
    });
  });
  
  test('handles view action', async () => {
    const rows = [{ id: 1, productName: 'Product 1', application_identifier: 'app-1' }];
    mockRowContextValues.rows = rows;

    render(
      
        <RowContext.Provider value={mockRowContextValues}>
          <BrowserRouter>
            <ApplicationDataGrid />
          </BrowserRouter>
        </RowContext.Provider>
      
    );

   
    expect(screen.getByRole('menu')).toBeInTheDocument();

    const moreButton = await screen.findByRole('menuitem', { name: /more/i });
    fireEvent.click(moreButton);
    const viewIcon = await screen.findByTestId('view-icon');
    fireEvent.click(viewIcon);

    await waitFor(() => {
      expect(mockNavigate).toHaveBeenCalledWith('/viewApplication');
    });
  });
});